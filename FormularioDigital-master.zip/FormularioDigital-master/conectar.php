<?php
$mysqli = new mysqli('localhost','root','','formulario');

if($mysqli ){
	echo "ok";
}
    $nombre = trim($_POST['nombre']);
	$apellidoPaterno = trim($_POST['apellidoPaterno']);
	$apellidoMaterno = trim($_POST['apellidoMaterno']);
	$fechaNacimiento = trim($_POST['fechaNacimiento']);
	$domicilio = trim($_POST['domicilio']);
    $email = trim($_POST['email']);
	$telefonoCelular = trim($_POST['telefonoCelular']);
	$telefonoCasa = trim($_POST['telefonoCasa']);
	$pais = trim($_POST['pais']);
if($pais==1){
$pais = "Prescolar";
}else if($pais==2){
$pais = "Primaria";
}else if($pais==3){
$pais= "Secundaria";
}else if($pais==4){
$pais= "Bachillerato";
}else if($pais==5){
$pais = "Licenciatura";
}else if($pais==6){
$pais = "Maestria";
}else if($pais==7){
$pais = "PostGrado";
}else if($pais==8){
$pais = "Idiomas";
} else if($pais==9){
$pais = "Otros Cursos";
}
	$tipoBeca = trim($_POST['tipoBeca']);
	$consulta = "INSERT INTO formulario(nombre,apellidoPaterno,apellidoMaterno,fechaNacimiento,domicilio,email,telefonoCelular,telefonoCasa,pais,tipoBeca) VALUES ('$nombre','$apellidoPaterno','$apellidoMaterno','$fechaNacimiento','$domicilio','$email','$telefonoCelular','$telefonoCasa','$pais','$tipoBeca')";
	
    $mysqli->query($consulta);

	echo $consulta;
	
	
?>