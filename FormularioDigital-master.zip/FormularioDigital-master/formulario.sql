-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-11-2020 a las 16:50:28
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `formulario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formulario`
--

CREATE TABLE `formulario` (
  `nombre` varchar(50) NOT NULL,
  `apellidoPaterno` varchar(50) NOT NULL,
  `apellidoMaterno` varchar(50) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `domicilio` varchar(300) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telefonoCelular` int(20) NOT NULL,
  `telefonoCasa` int(20) NOT NULL,
  `pais` varchar(200) NOT NULL,
  `tipoBeca` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `formulario`
--

INSERT INTO `formulario` (`nombre`, `apellidoPaterno`, `apellidoMaterno`, `fechaNacimiento`, `domicilio`, `email`, `telefonoCelular`, `telefonoCasa`, `pais`, `tipoBeca`) VALUES
('Ivan', 'Lopez', 'Rosales', '2020-11-13', 'Villa de las flores', 'munossandy770@gmail.com', 2147483647, 2147483647, '0', '0'),
('Ivan', 'Lopez', 'Rosales', '2020-11-10', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, '7', 'Universidad de las Ciencias Panales'),
('Ivan', 'Lopez', 'Rosales', '2020-11-10', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, '5', 'Grupo Universitario Modelo'),
('Ivan', 'Lopez', 'Rosales', '2020-11-10', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, '1', 'Corporativo Universitario MÃ©xico'),
('Ivan', 'Lopez', 'Rosales', '2020-11-10', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, '1', ''),
('Ivan', 'Lopez', 'Rosales', '2020-11-10', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, '2', 'Primaria'),
('Ivan', 'Lopez', 'Rosales', '2020-11-10', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, '2', ''),
('Ivan', 'Lopez', 'Rosales', '2020-11-10', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, '1', 'Preescolar'),
('Ivan', 'Lopez', 'Rosales', '2020-11-25', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, 'Prescolar', 'Preescolar'),
('Ivan', 'Lopez', 'Rosales', '2020-11-25', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, 'Maestria', 'Universidad CNDI'),
('Ivan', 'Lopez', 'Rosales', '2020-11-25', 'Villa de las flores', 'sandy_lukiz1@hotmail.com', 2147483647, 2147483647, 'Idiomas', 'Idiomas'),
('Ivan', 'Lopez', 'Rosales', '2020-11-20', 'Villa de las flores', 'munossandy770@gmail.com', 2147483647, 2147483647, 'Idiomas', 'LYCEUM');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
